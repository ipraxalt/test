<?php
namespace Company\Test\Controller\Index; 
use Magento\Framework\App\Action\Action;
use Magento\Framework\Controller\ResultFactory;
 
class Post extends Action{
    public function execute(){
		
            $fname = $this->getRequest()->getPostValue("fname");
			$phone = $this->getRequest()->getPostValue("phone");
		    $email = $this->getRequest()->getPostValue("email");			
			$date = '';
			$country = $this->getRequest()->getPostValue("country");
		    $state = $this->getRequest()->getPostValue("state");
			
			$item = $this->_objectManager->create("Company\Test\Model\Test");
            $item->setName($fname);
			$item->setPhone($phone);
			$item->setEmail($email);			
			$item->setdate($date);
			$item->setCountry($country);
			$item->setState($state);			  
            $item->save();
			
            $redirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            //$redirect->setUrl($this->_redirect->getRefererUrl());
            //$redirect->setUrl("/magento21/test");
            //return $redirect;
			
    		$this->messageManager->addSuccess( __('Thanks for contacting us'));			
			
			$redirect->setUrl("/Magento21/test");
			
            return $redirect;
			
	}
}